import os
# Assuming external_lib is integrated either via file copy or package installation
try:
    # This import path assumes the external_lib was copied into
    # src/my_app/external_lib_integration/
    from my_app.external_lib_integration.utils import greet_external_user
except ImportError:
    # Fallback for local run without full external_lib integration setup
    # or if external_lib is intended to be installed as a separate package
    # (in which case the import would be 'from external_lib.utils import ...')
    def greet_external_user(name):
        return f"Hello, {{name}} from a placeholder external library!"

def main():
    print("Welcome to my CI/CD enabled Python app!")
    user_name = os.getenv("USERNAME", "there") # Get username from env var, default to 'there'
    print(greet_external_user(user_name))
    print("This app will be built and deployed via CI/CD!")

if __name__ == "__main__":
    main()