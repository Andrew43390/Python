# my_ci_cd_app

This is a Python application designed with a CI/CD pipeline in mind.

## CI/CD Pipeline

The CI/CD pipeline is defined in `.github/workflows/ci_cd.yml` (if using GitHub Actions) and handles:
- Dependency management (using Poetry)
- Cloning and integrating code from an external Git repository
- Running linters (flake8)
- Running tests (pytest)
- Building a Python package (.whl)
- Building a standalone executable (PyInstaller)
- Deployment (example stages for PyPI and S3)

## External Repository Integration

This project is set up to integrate code from an external Git repository, as configured in the CI/CD pipeline.